package middler

import (
	"DEMOX_ADMINAUTH/internal/ctx"
	"github.com/gin-contrib/requestid"
	"github.com/gin-gonic/gin"
)

// 批量注册全局中间件
func RegMiddler(appctx *ctx.AppContext) []gin.HandlerFunc {
	return []gin.HandlerFunc{
		requestid.New(),
		Recovery(appctx),
		appctx.Tracer.GinMiddler(),
		HttpLog(appctx),
		Cors(),
		PromMiddler(appctx),
	}
}
