package app

import (
	"DEMOX_ADMIN/internal/app/admin/adminmodel"
	"DEMOX_ADMIN/internal/ctx"
)

var Tables = []interface{}{
	&adminmodel.AdminPo{},
}

func Regdb(appctx *ctx.AppContext) error {
	return appctx.Db.Set("gorm:ble_options", "ENGINE=InnoDB DEFAULT CHARSET=utf8").AutoMigrate(Tables...)
}
