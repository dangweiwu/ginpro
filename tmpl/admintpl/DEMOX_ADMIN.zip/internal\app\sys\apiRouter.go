package sys

import (
	"DEMOX_ADMIN/internal/app/sys/api"
	"DEMOX_ADMIN/internal/ctx"
	"DEMOX_ADMIN/internal/router"
	"github.com/gin-gonic/gin"
)

// @group | sys | 3 | 系统设置 | 包括链路追踪,指标采集
func Route(r *router.Router, sc *ctx.AppContext) {
	r.Root.GET("/sys", gin.BasicAuth(gin.Accounts{sc.Config.App.Name: sc.Config.App.Password}), router.Do(sc, api.NewSysQuery))
	r.Root.PUT("/sys", gin.BasicAuth(gin.Accounts{sc.Config.App.Name: sc.Config.App.Password}), router.Do(sc, api.NewSysAct))
}
