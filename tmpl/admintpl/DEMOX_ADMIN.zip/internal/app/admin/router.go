package admin

import (
	"DEMOX_ADMIN/internal/app/admin/api"
	"DEMOX_ADMIN/internal/ctx"
	"DEMOX_ADMIN/internal/router"
)

// @group | admin | 1 | 用户管理 | 系统用户管理 增删查改
func Route(r *router.Router, appctx *ctx.AppContext) {

	r.Jwt.GET("/admin", router.Do(appctx, api.NewAdminQuery))

	r.Jwt.POST("/admin", router.Do(appctx, api.NewAdminCreate))

	r.Jwt.PUT("/admin/:id", router.Do(appctx, api.NewAdminUpdate))

	r.Jwt.DELETE("/admin/:id", router.Do(appctx, api.NewAdminDel))

	r.Jwt.PUT("/admin/resetpwd/:id", router.Do(appctx, api.NewResetPassword))

}
