package my

import (
	"DEMOX_ADMIN/internal/app/my/api"
	"DEMOX_ADMIN/internal/ctx"
	"DEMOX_ADMIN/internal/router"
)

// @group | me | 2 | 系统我的 | 包括基本信息获取修改 登录登出 token刷新
func Route(r *router.Router, sc *ctx.AppContext) {

	r.Jwt.GET("/my", router.Do(sc, api.NewMyInfo))

	r.Jwt.PUT("/my", router.Do(sc, api.NewMyUpdate))

	r.Jwt.PUT("/my/password", router.Do(sc, api.NewMyUpdatePwd))

	r.Root.POST("/login", router.Do(sc, api.NewLogin))

	r.Jwt.POST("/logout", router.Do(sc, api.NewLogOut))

	r.Jwt.POST("/token/refresh", router.Do(sc, api.NewRefreshToken))

}
