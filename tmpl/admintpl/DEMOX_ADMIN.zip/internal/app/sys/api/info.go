package api

import (
	"DEMOX_ADMIN/internal/app/sys/sysmodel"
	"DEMOX_ADMIN/internal/ctx"
	"DEMOX_ADMIN/internal/pkg/api/hd"
	"DEMOX_ADMIN/internal/router/irouter"
	"github.com/dangweiwu/ginpro/pkg/metric"
	"github.com/gin-gonic/gin"
	"time"
)

type SysQuery struct {
	*hd.Hd
	ctx    *gin.Context
	appctx *ctx.AppContext
}

func NewSysQuery(c *gin.Context, appctx *ctx.AppContext) irouter.IHandler {
	return &SysQuery{hd.NewHd(c), c, appctx}
}

// Do
// @api | sys | 1 | 运行状态
// @path | /api/sys
// @method | GET
// @header |n  Authorization |d 权限 |t type |c bascAuth base64(name:password)
// @response | sysmodel.SysVo | 200 Response
func (this *SysQuery) Do() error {
	vo := &sysmodel.SysVo{}
	vo.StartTime = this.appctx.StartTime.String()
	vo.RunTime = time.Now().Sub(this.appctx.StartTime).String()
	if this.appctx.Tracer.IsEnable() {
		vo.OpenTrace = "1"
	} else {
		vo.OpenTrace = "0"
	}

	if metric.Enabled() {
		vo.OpenMetric = "1"
	} else {
		vo.OpenMetric = "0"
	}

	this.Rep(vo)
	return nil
}
