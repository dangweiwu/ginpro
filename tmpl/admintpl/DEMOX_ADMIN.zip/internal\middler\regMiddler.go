package middler

import (
	"DEMOX_ADMIN/internal/ctx"
	"github.com/gin-contrib/requestid"
	"github.com/gin-gonic/gin"
)

//批量注册全局中间件
func RegMiddler(sc *ctx.AppContext) []gin.HandlerFunc {
	return []gin.HandlerFunc{
		requestid.New(),
		Recovery(sc),
		sc.Tracer.GinMiddler(),
		HttpLog(sc),
		Cors(),
		PromMiddler(sc),
	}
}
