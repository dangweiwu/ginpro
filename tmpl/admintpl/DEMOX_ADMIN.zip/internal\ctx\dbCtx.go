package ctx

import (
	"DEMOX_ADMIN/internal/config"
	"DEMOX_ADMIN/internal/pkg/lg"
	"github.com/dangweiwu/ginpro/pkg/logx"
	"github.com/dangweiwu/ginpro/pkg/mysqlx"
	errs "github.com/pkg/errors"
)

func NewDbContext(c config.Config) (*AppContext, error) {
	//初始化日志
	sc := &AppContext{}
	sc.Config = c
	if lg, err := logx.NewLogx(c.Log); err != nil {
		return nil, err
	} else {
		sc.Log = lg
	}

	//初始化数据库
	db := mysqlx.NewDb(c.Mysql)
	if d, err := db.GetDb(); err != nil {
		return nil, errs.WithMessage(err, "err init db")
	} else {
		//d.Debug()
		sc.Db = d
		lg.Msg("数据库链接成功").Info(sc.Log)
	}
	return sc, nil
}
