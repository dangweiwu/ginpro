package app

import (
	"DEMOX_ADMIN/internal/app/admin"
	"DEMOX_ADMIN/internal/app/my"
	"DEMOX_ADMIN/internal/app/sys"
	"DEMOX_ADMIN/internal/ctx"
	"DEMOX_ADMIN/internal/router"
	"github.com/gin-gonic/gin"
)

var routes = []func(r *router.Router, appctx *ctx.AppContext){
	admin.Route,
	my.Route,
	sys.Route,
}

func RegisterRoute(engine *gin.Engine, appctx *ctx.AppContext) {
	r := router.NewRouter(engine, appctx)
	//regroute
	for _, v := range routes {
		v(r, appctx)
	}
}
