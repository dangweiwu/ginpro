package config

import (
	"github.com/dangweiwu/ginpro/api/apiserver/apiconfig"
	"github.com/dangweiwu/ginpro/pkg/logx"
)

//全局配置文件
type Config struct {
	Api apiconfig.ApiConfig
	Log logx.LogxConfig
}
